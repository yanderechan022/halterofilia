<!DOCTYPE html>
<html lang="en">
<head>
	<title>Inicio</title>
 <meta charset="utf-8">
         <meta http-equiv="X-UA-Compatible" content="IE=edge">
         <meta name="viewport" content="width=device-width, initial-scale=1">
         <title></title>
         <meta name="description" content="Source code generated using layoutit.com">
         <meta name="author" content="LayoutIt!">
         <link href="css/bootstrap.min.css" rel="stylesheet">
         <link href="formulariocss.css" rel="stylesheet">
         <link href="framework/css/bootstrap.css"rel="stylesheet">
     	</head>
      


</head>
<header>

	
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">

	<div class="container">	
		<img class="logo" align="left" src='logo.png' width="483" height="120" />
<div class="collapse navbar-collapse" id="navbarResponsive">
		
		<ul class="menu">
  <li><a href="#">INICIO</a></li>
  <li><a href="#">CONTACTENOS</a></li>
  <li><a href="#">REGISTRO</a></li>
  <li><a href="login.php">LOGIN </a></li>
</ul>
</nav>
</header>

<body>

<img class="imagen2" src="carro.png">

<p class=art1>MOTCARSPEED</p>
<div class="texto">
<p class="art2">
 	<br>
 	<br>
 	<br>
	Algo anda mal con tu vehiculo, vez alguna luz o señal que te preocupe? 
	<br>
	<br>
	Traelo a nuestros talleres MOTOCARSPEED y le daremos a tu vehiculo la mejor atención para que la perdurabilidad de este sea mayor y puedas usarlo con la mayor tranquilidad posible. 
	<br>
	<br>
	Nuestra Experiencia, equipo, calidad, confiabilidad y seguridad le brindan a tu carro y motor un servicio sin igual, siempre de la mano con productos 100% originales.


</p>
</div>
<div class="rectangle bg-black skew-left"></div>
		<div class="section bg-black" id="footer">
			<div class="center-align">
				<div class="section-columns" >
					<div>
						<h2 class="white">Sigamos en Contacto.</h2>
						<div class="btn-section">
							<a href="mailto: contacto@misitio.com" class="btn btn-white">Mándame un mensaje</a>
						</div>
					</div>

					<div>
						<h3>Contáctame si quieres conocerme y saber cómo podemos colaborar en tu siguiente proyecto.</h3>
						<p>También puedes estar conmigo por medio de las redes sociales, enterarte de mi más reciente trabajo y conocerme un poco más.</p>

       <div class="btn-section">
							<a href="http://www.facebook.com/misitio/" class="btn btn-white">Facebook</a>
							<a href="http://www.twitter.com/misitio/" class="btn btn-white">Twitter</a>
							<a href="http://www.instagram.com/misitio/" class="btn btn-white">Instagram</a>
</div>
</body>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/scripts.js"></script>
</html>