<!DOCTYPE html>
<html>
	 <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <title>SOFWEIGHTLIFTING</title>

    <meta name="description" content="Source code generated using layoutit.com">
    <meta name="author" content="LayoutIt!">

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="ingresousuariocss.css" rel="stylesheet">

  </head>
   
   <div class="col-sm-12 col-md-12"> 
	<ul>
		<li> <img src="logo.png"></li>
	</ul>
</div>
<body>
<form action="recogercliente.php" method="post">



 
<div class="container-fluid">
<div class="row">
 	<div class="col-sm-12 col-md-12">
 		<div class="row">
 			<div class="col-md-12">
 				<div class="page-header">

<center>

		<h1>
 		SOFWEIGHTLIFTING
	</h1>
	<br><br>	
<div class="panel panel-default">
	<div class="col-sm-12 col-md-12">
  <div class="panel-body" >
<a class="btn btn-principally" id="principal" >INGRESO USUARIOS</a>
<br>
<br>

<a class="btn btn-primary" href="deportista.php" id="depo">DEPORTISTAS</a>
<br>
<br>
<a class="btn btn-secundary" href="jueces.php" id="jueces">JUECES</a>
<br>
<br>
<a class="btn btn-entrenadores" href="entrenadores.php" id="entre">ENTRENADORES</a>
<br>
<br>
<a class="btn btn-quaternary"href="" id="menu"class="button">MENU PRINCIPAL</a>
<br>
<br>
   
 <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>
</div>
</div>
</div>
</div>
</div>
</div>
</center>	
</body>
</html>