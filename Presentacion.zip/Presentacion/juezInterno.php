<!DOCTYPE html>
<html>
	 <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <title>SOFWEIGHTLIFTING</title>

    <meta name="description" content="Source code generated using layoutit.com">
    <meta name="author" content="LayoutIt!">

    <link href="pesas/src/css/bootstrap.min.css" rel="stylesheet">
    <link href="estilosTabla.css" rel="stylesheet">

  </head>
  <a href="login.php"><img class="ca" src="casa.png"></a></h2></a>  
   <div class="col-sm-12 col-md-12"> 
	<ul>
		<li> <img src="logo.png"></li>
	</ul>
</div>
<body>
<center>
<table class="planilla">
  <thead style="background: rgba(185, 193, 192) border: 3px solid rgba(23, 27, 26);">
    <tr>
      <th rowspan="2">G</th>
      <th rowspan="2">NOMBRE</th>
      <th rowspan="2">MUNICIPIO</th>
      <th rowspan="2">AÑO DE NACIMIENTO</th>
      <th rowspan="2">PC</th>
      <th colspan="6">ARRANQUE KG</th>
      <th colspan="6">ENVIÓN KG</th>
       <th rowspan="2">TOTAL</th>
       <th rowspan="2">LUGAR</th>
       <th rowspan="2">PUNTOS</th>
       <th rowspan="2">PUNTAJE FINAL</th>
       <th rowspan="2">SINCLAIR</th>     
    </tr>
    <tr>
      <th scope="col">1</th>
      <th>2</th>
      <th>3</th>
      <th>Arranque</th>
      <th>Lugar</th>
      <th>Puntos</th>
      <th scope="col">1</th>
      <th>2</th>
      <th>3</th>
      <th>Arranque</th>
      <th>Lugar</th>
      <th>Puntos</th>
    </tr>
  </thead>
      <a class="btn btn-principally" id="principal" >SOFTWEITHLIFTING COMPETENCIA</a>
    <tbody>
    <tr>
      <th style="background: rgba(128, 255, 0, 0.3); border: 3px solid rgba(23, 27, 26);">001</th>
      <td style="background: rgba(255, 128, 0, 0.3); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(59, 204, 180); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(195, 243, 235); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(183, 194, 241); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(255, 147, 68); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(50, 241, 250); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(250, 66, 50); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(200, 183, 254); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(183, 254, 191); border: 3px solid rgba(23, 27, 26);"></td>    
    </tr>
        <tr>
      <th style="background: rgba(128, 255, 0, 0.3); border: 3px solid rgba(23, 27, 26);">001</th>
      <td style="background: rgba(255, 128, 0, 0.3); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(59, 204, 180); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(195, 243, 235); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(183, 194, 241); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(255, 147, 68); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(50, 241, 250); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(250, 66, 50); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(200, 183, 254); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(183, 254, 191); border: 3px solid rgba(23, 27, 26);"></td>    
    </tr>
        <tr>
      <th style="background: rgba(128, 255, 0, 0.3); border: 3px solid rgba(23, 27, 26);">001</th>
      <td style="background: rgba(255, 128, 0, 0.3); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(59, 204, 180); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(195, 243, 235); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(183, 194, 241); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(255, 147, 68); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(50, 241, 250); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(250, 66, 50); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(200, 183, 254); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(183, 254, 191); border: 3px solid rgba(23, 27, 26);"></td>    
    </tr>
        <tr>
      <th style="background: rgba(128, 255, 0, 0.3); border: 3px solid rgba(23, 27, 26);">001</th>
      <td style="background: rgba(255, 128, 0, 0.3); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(59, 204, 180); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(195, 243, 235); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(183, 194, 241); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(255, 147, 68); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(50, 241, 250); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(250, 66, 50); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(200, 183, 254); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(183, 254, 191); border: 3px solid rgba(23, 27, 26);"></td>    
    </tr>
        <tr>
      <th style="background: rgba(128, 255, 0, 0.3); border: 3px solid rgba(23, 27, 26);">001</th>
      <td style="background: rgba(255, 128, 0, 0.3); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(59, 204, 180); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(195, 243, 235); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(183, 194, 241); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(255, 147, 68); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(50, 241, 250); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(250, 66, 50); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(200, 183, 254); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(183, 254, 191); border: 3px solid rgba(23, 27, 26);"></td>    
    </tr>
        <tr>
      <th style="background: rgba(128, 255, 0, 0.3); border: 3px solid rgba(23, 27, 26);">001</th>
      <td style="background: rgba(255, 128, 0, 0.3); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(59, 204, 180); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(195, 243, 235); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(183, 194, 241); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(255, 147, 68); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(50, 241, 250); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(250, 66, 50); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(200, 183, 254); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(183, 254, 191); border: 3px solid rgba(23, 27, 26);"></td>    
    </tr>
        <tr>
      <th style="background: rgba(128, 255, 0, 0.3); border: 3px solid rgba(23, 27, 26);">001</th>
      <td style="background: rgba(255, 128, 0, 0.3); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(59, 204, 180); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(195, 243, 235); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(183, 194, 241); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(255, 147, 68); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(50, 241, 250); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(250, 66, 50); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(200, 183, 254); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(183, 254, 191); border: 3px solid rgba(23, 27, 26);"></td>    
    </tr>
        <tr>
      <th style="background: rgba(128, 255, 0, 0.3); border: 3px solid rgba(23, 27, 26);">001</th>
      <td style="background: rgba(255, 128, 0, 0.3); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(59, 204, 180); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(195, 243, 235); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(183, 194, 241); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(255, 147, 68); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(50, 241, 250); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(250, 66, 50); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(200, 183, 254); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(183, 254, 191); border: 3px solid rgba(23, 27, 26);"></td>    
    </tr>
        <tr>
      <th style="background: rgba(128, 255, 0, 0.3); border: 3px solid rgba(23, 27, 26);">001</th>
      <td style="background: rgba(255, 128, 0, 0.3); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(59, 204, 180); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(195, 243, 235); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(183, 194, 241); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(255, 147, 68); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(50, 241, 250); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(250, 66, 50); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(200, 183, 254); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(183, 254, 191); border: 3px solid rgba(23, 27, 26);"></td>    
    </tr>
        <tr>
      <th style="background: rgba(128, 255, 0, 0.3); border: 3px solid rgba(23, 27, 26);">001</th>
      <td style="background: rgba(255, 128, 0, 0.3); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(59, 204, 180); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(195, 243, 235); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(183, 194, 241); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(104, 203, 170); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(37, 61, 231); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(251, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(218, 254, 201); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(255, 147, 68); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(50, 241, 250); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(250, 66, 50); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(200, 183, 254); border: 3px solid rgba(23, 27, 26);"></td>
      <td style="background: rgba(183, 254, 191); border: 3px solid rgba(23, 27, 26);"></td>    
    </tr>
  </tbody>
  </table>
  </center>
</body>
</html>