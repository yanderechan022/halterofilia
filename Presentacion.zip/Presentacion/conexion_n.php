
<?php
$conexion_n = new mysqli ("127.0.0.1:33065", "root","", "halterofilia");


?>
