<!DOCTYPE html>
<html>
	 <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <title>SOFWEIGHTLIFTING</title>

    <meta name="description" content="Source code generated using layoutit.com">
    <meta name="author" content="LayoutIt!">
    <link href="fisio.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">

  </head>
  <body>

<!-- Espacio para el header y el logo-->
<!--<div class="container-fluid">
  <div class="row">
    <div class=" <con col-md-1>">
    <img src="fondo.png" class="img-reponsive" alt="">-->
            <div class="container-fluid">
     <section class="main row">
    <article class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
      <p>
        <img src="logo.png" class="img-responsive" onclick="window.location.href='depor.php'" border="0" width="140" height="140">
        
      </p>
    </article>
    <aside class="col-xs-8 col-sm-8 col-md-8 col-lg-8">
      <center><p>
      <h1><center>SOFWEIGHTLIFTING<center></h1>
      </p></center>
    </aside>
    <footer class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
      <p>
      <h1></h1>
      </p>
   </section>
    
   </div>

<!---botones-->
   <div class="container col-sm-12">
         <div class="col-sm-4">
         </div>  

        <div class="caja col-sm-4 col-xs-12">
          <br>
          <br>
          <center>
            <div class="col-sm-1">
         </div>  

            <form action="recogercliente.php" class="frm-form col-sm-10 " method="post">

            <a class="btn btn-principally col-sm-12 col-xs-12 "  id="principal" >NUTRICIONISTA</a>
            <br>
            <br>
            <br>
            <br>
            <a class="btn btn-primary col-xs-12 col-sm-12 col-md-12 col-lg-12" href="infor_deportista.php" id="depo">INFORME DE DEPORTISTA</a>
            <br>
            <br>
            <br>
            <br>
            <a class="btn btn-primary col-xs-12 col-sm-12 col-md-12 col-lg-12" href="jueces.php" id="jueces">CURVA DE RENDIMIENTO</a>
            <br>
            <br>
            <br>
            <br>
            <a class="btn btn-primary col-xs-12 col-sm-12 col-md-12 col-lg-12" href="login.php" id="menu" >MENU PRINCIPAL</a>
            <br>
            <br>
             <br>
            <br>
            </form>
            <div class="col-sm-1">
         </div>  

            </center>
            <br>
            <br>
        </div>

       <div class="col-sm-4">
       </div>


  </div>


 <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>



</body>
</html>