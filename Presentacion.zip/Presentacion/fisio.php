<!DOCTYPE html>
<html>
	 <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <title>SOFTWEIGHTLIFTING</title>

    <meta name="description" content="Source code generated using layoutit.com">
    <meta name="author" content="LayoutIt!">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="fisio.css" rel="stylesheet">

  </head>
  <body>
    

<!-- Espacio para el header y el logo-->
<!--<div class="container-fluid">
  <div class="row">
    <div class=" <con col-md-1>">
    <img src="fondo.png" class="img-reponsive" alt="">-->
           <br>
           <div class="container-fluid">
              <div class="row">
                   <div class=" con col-md-3"> 
        	             <ul>
        		              <li> <img src="logo.png" class="img-responsive" alt=""></li>
        	             </ul>
                    </div>
                   
                      <div class="tit col-md-6"><center><h1>SOFWEIGHTLIFTING</h1></center></div>
                        <button type="button" class="btn btn-principally col-md-2" id="principal">ACTUALIZACION</button>
             </div>
          </div>
          <br>
            <br>

<!---botones-->
   <div class="container col-sm-12">
         <div class="col-sm-4">
         </div>  

        <div class="caja col-sm-4 col-xs-12">
          <br>
          <br>
          <center>
            <div class="col-sm-1">
         </div>  

            <form action="recogercliente.php" class="frm-form col-sm-10 " method="post">

            <a class="btn btn-principally  col- sx-12 col-sm-12 col-md-12 col-lg-12 "  id="principal" >FISIOTERAPEUTA</a>
            <br>
            <br>
            <br>
            <br>
            <a class="btn btn-primary col-xs-12 col-sm-12 col-md-12 col-lg-12 " href="deportista.php" id="depo">INFORME DE DEPORTISTA</a>
            <br>
            <br>
            <br>
            <br>
            <a class="btn btn-primary col-xs-12 col-sm-12 col-md-12 col-lg-12" href="jueces.php" id="jueces">CURVA DE RENDIMIENTO</a>
            <br>
            <br>
            <br>
            <br>
            <a class="btn btn-primary col-xs-12 col-sm-12 col-md-12 col-lg-12" href="" id="menu" >MENU PRINCIPAL</a>
            <br>
            <br>
             <br>
            <br>
            </form>
            <div class="col-sm-1">
         </div>  

            </center>
            <br>
            <br>
        </div>

       <div class="col-sm-4">
       </div>


  </div>


 <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>



</body>
</html>